﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CMS
{
    /// <summary>
    /// Interaction logic for ShowWindow.xaml
    /// </summary>
    public partial class ShowWindow : Window
    {
        public static ObservableCollection<FootbalPlayers> FootballPlayers { get; set; }
        private DataIO serializer = new DataIO();
        public string Username { get; set; }
        public string Password { get; set; }

        public ShowWindow()
        {
            FootballPlayers = new ObservableCollection<FootbalPlayers>();
            FootballPlayers = serializer.DeSerializeObject<ObservableCollection<FootbalPlayers>>("igraci.xml");
            DataContext = this;
            InitializeComponent();
        }

        private void Canvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void Add_Button_Click(object sender, RoutedEventArgs e)
        {
            AddWindow addWindow = new AddWindow();
            addWindow.ShowDialog();
        }

        private void Delete_Button_Click(object sender, RoutedEventArgs e)
        {
            var playersToRemove = FootballPlayers.Where(p => p.IsSelected).ToList();

            if (playersToRemove.Count > 0)
            {
                var result = MessageBox.Show("Are you sure you want to delete the selected players?", "Delete Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {

                    foreach (var player in playersToRemove)
                    {
                        FootballPlayers.Remove(player);
                        File.Delete(player.RtfFilePath);
                    }


                    serializer.SerializeObject(FootballPlayers, "igraci.xml");

                    MessageBox.Show("Players successfully deleted.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("No players selected for deletion.", "No Players", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }


        private void DataGridPlayers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Update IsSelected property for all selected players
            foreach (var selectedItem in DataGridPlayers.SelectedItems)
            {
                if (selectedItem is FootbalPlayers selectedPlayer)
                {
                    // Find the corresponding player in the collection and set IsSelected to true
                    var player = FootballPlayers.FirstOrDefault(p => p.Equals(selectedPlayer));
                    if (player != null)
                    {
                        player.IsSelected = true;
                    }
                }
            }

            // Save changes to the XML file
            serializer.SerializeObject(FootballPlayers, "igraci.xml");
        }

        private void Exit_Button_Click(object sender, RoutedEventArgs e)
        {
            foreach (var player in ShowWindow.FootballPlayers)
            {
                if (player.IsSelected)
                {
                    // Postavi IsSelected na false za ovog igrača
                    player.IsSelected = false;
                }
            }

            // Sačuvajte promene u XML datoteci ako je potrebno
            serializer.SerializeObject(ShowWindow.FootballPlayers, "igraci.xml");

            // Otvori glavni prozor i zatvori trenutni prozor
            MainWindow main = new MainWindow();
            main.Show();
            Close(); 
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            FootbalPlayers selectedPlayer = (sender as Hyperlink).Tag as FootbalPlayers;

            UserRoleEnum userRole = DetermineUserRole(Username, Password);

            if (userRole == UserRoleEnum.Admin)
            {
                EditWindow editWindow = new EditWindow(selectedPlayer);
                editWindow.ShowDialog();
            }
            else if (userRole == UserRoleEnum.Visitor)
            {
                ViewWindow viewWindow = new ViewWindow(selectedPlayer);
                viewWindow.ShowDialog();
            }
        }

        private UserRoleEnum DetermineUserRole(string username, string password)
        {
            UserRole user = new UserRole { Username = username, Password = password };
            if (username.ToLower() == "admin" && password.ToLower() == "admin123")
            {
                user.Role = UserRoleEnum.Admin;
                return user.Role;
            }
            else if (username.ToLower() == "visitor" && password.ToLower() == "visitor123")
            {
                user.Role = UserRoleEnum.Visitor;
                return user.Role;
            }
            else
            {
                throw new InvalidOperationException("Invalid username or password.");
            }
        }

        private void PlayerCheckBox_Click(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;

            // Find the corresponding player associated with the checkbox
            if (checkBox != null && checkBox.DataContext is FootbalPlayers player)
            {
                // Update IsSelected property of the player based on the checkbox state
                player.IsSelected = checkBox.IsChecked ?? false;

                // Save changes to the XML file
                serializer.SerializeObject(FootballPlayers, "igraci.xml");
            }
        }
    }
}