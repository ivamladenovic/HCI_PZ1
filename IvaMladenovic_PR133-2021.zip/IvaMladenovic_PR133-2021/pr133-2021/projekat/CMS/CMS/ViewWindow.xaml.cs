﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CMS
{
    /// <summary>
    /// Interaction logic for ViewWindow.xaml
    /// </summary>
    public partial class ViewWindow : Window
    {
        private FootbalPlayers selectedPlayer;
        private DataIO serializer = new DataIO();

        public ViewWindow(FootbalPlayers selectedPlayer)
        {
            InitializeComponent();
            this.selectedPlayer = selectedPlayer;
            NameAndSurname.Content = selectedPlayer.NameAndSurname;
            DressNumber.Content = selectedPlayer.ShirtNumber.ToString();
            Uri fileUri = new Uri(selectedPlayer.ImagePath, UriKind.Relative);
            ImageView.Source = new BitmapImage(fileUri);
            DateTimeBox.Content = selectedPlayer.DateTime.ToString("dd/MM/yyyy");


            if (File.Exists(selectedPlayer.RtfFilePath))
            {
                FlowDocument doc = new FlowDocument();
                TextRange range = new TextRange(doc.ContentStart, doc.ContentEnd);
                using (FileStream fStream = new FileStream(selectedPlayer.RtfFilePath, FileMode.OpenOrCreate))
                {
                    range.Load(fStream, DataFormats.Rtf);
                }
                RichBox.Document = doc;
            }
        }

        private void ViewWindowCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            selectedPlayer.IsSelected = false;

            // Sačuvajte promene u XML datoteci ako je potrebno
            serializer.SerializeObject(ShowWindow.FootballPlayers, "igraci.xml");
            Close();
        }
    }
}
