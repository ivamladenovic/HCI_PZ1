﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace CMS
{
    public class FootbalPlayers : INotifyPropertyChanged
    {
        private int shirtNumber;
        private string nameAndSurname;
        private string imagePath;
        private string rtfFilePath;
        private DateTime dateTime;
        private bool isSelected;
        public bool IsSelected
        {
            get { return isSelected; }
            set
            {
                if (isSelected != value)
                {
                    isSelected = value;
                    OnPropertyChanged("IsSelected");
                }
            }
        }

        public FootbalPlayers()
        {
        }

        public FootbalPlayers(int shirtNumber, string nameAndSurname, string imagePath, string rtfFilePath, DateTime dateTime)
        {
            this.shirtNumber = shirtNumber;
            this.nameAndSurname = nameAndSurname;
            this.imagePath = imagePath;
            this.rtfFilePath = rtfFilePath;
            this.dateTime = dateTime;
        }


        public int ShirtNumber
        {
            get => shirtNumber;
            set
            {
                shirtNumber = value;
                OnPropertyChanged(nameof(ShirtNumber));
            }
        }

        public string NameAndSurname
        {
            get => nameAndSurname;
            set
            {
                nameAndSurname = value;
                OnPropertyChanged(nameof(NameAndSurname));
            }
        }

        public string ImagePath
        {
            get => imagePath;
            set
            {
                imagePath = value;
                OnPropertyChanged(nameof(ImagePath));
            }
        }

        public string RtfFilePath
        {
            get => rtfFilePath;
            set
            {
                rtfFilePath = value;
                OnPropertyChanged(nameof(RtfFilePath));
            }
        }

        public DateTime DateTime
        {
            get => dateTime;
            set
            {
                dateTime = value;
                OnPropertyChanged(nameof(DateTime));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
