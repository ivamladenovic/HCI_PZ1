﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;
using System.IO;
using System.Xml.Serialization;
using System.Collections.ObjectModel;

namespace CMS
{
    /// <summary>
    /// Interaction logic for AddWindow.xaml
    /// </summary>
    public partial class AddWindow : Window
    {
        private string bp;
        private FootbalPlayers footbalPlayers = new FootbalPlayers();
        private DataIO serializer = new DataIO();
        public AddWindow()
        {         
            InitializeComponent();
            DressTextBox.Text = "Input dress number";
            DressTextBox.Foreground = Brushes.LightGray;
            UserTextBox.Text = "Input name and surname";
            UserTextBox.Foreground = Brushes.LightGray;
            ComboBoxFamily.ItemsSource = Fonts.SystemFontFamilies.OrderBy(f => f.Source);
            ComboBoxFamily.SelectedIndex = 1;
            ComboBoxSize.ItemsSource = new List<double> { 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30 };
            ComboBoxSize.SelectedIndex = 4;
            ComboBoxColor.ItemsSource = typeof(Colors).GetProperties().Select(p => p.Name);
            ComboBoxColor.SelectedIndex = 7;

        }
        private bool colorComboBoxInitialized = false;

        private void ComboBoxColor_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboBoxColor.SelectedValue != null && !RichTextBox_AddWindiw.Selection.IsEmpty)
            {
                SolidColorBrush colorBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(ComboBoxColor.SelectedValue.ToString()));
                RichTextBox_AddWindiw.Selection.ApplyPropertyValue(Inline.ForegroundProperty, colorBrush);
            }

        }

        private void ComboBoxSize_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboBoxSize.SelectedValue != null && !RichTextBox_AddWindiw.Selection.IsEmpty)
            {
                RichTextBox_AddWindiw.Selection.ApplyPropertyValue(Inline.FontSizeProperty, ComboBoxSize.SelectedValue);
            }
        }

        private void ComboBoxFamily_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboBoxFamily.SelectedItem != null && !RichTextBox_AddWindiw.Selection.IsEmpty)
            {
                RichTextBox_AddWindiw.Selection.ApplyPropertyValue(Inline.FontFamilyProperty, ComboBoxFamily.SelectedItem);
            }

        }

        private void RichTextBox_AddWindiw_SelectionChanged(object sender, RoutedEventArgs e)
        {
            object temp = RichTextBox_AddWindiw.Selection.GetPropertyValue(Inline.FontStyleProperty);
            tglButtonItalic.IsChecked = (temp != DependencyProperty.UnsetValue) && (temp.Equals(FontStyles.Italic));

            temp = RichTextBox_AddWindiw.Selection.GetPropertyValue(Inline.FontWeightProperty);
            tglButtonBold.IsChecked = (temp != DependencyProperty.UnsetValue) && (temp.Equals(FontWeights.Bold));

            temp = RichTextBox_AddWindiw.Selection.GetPropertyValue(Inline.TextDecorationsProperty);
            tglButtonUnderline.IsChecked = (temp != DependencyProperty.UnsetValue) && (temp.Equals(TextDecorations.Underline));

            temp = RichTextBox_AddWindiw.Selection.GetPropertyValue(Inline.FontFamilyProperty);
            ComboBoxFamily.SelectedItem = temp;

            temp = RichTextBox_AddWindiw.Selection.GetPropertyValue(Inline.FontSizeProperty);
            ComboBoxSize.Text = temp.ToString();

            if (!colorComboBoxInitialized)
            {
                InitializeColorComboBox();
                colorComboBoxInitialized = true;
            }
            temp = RichTextBox_AddWindiw.Selection.GetPropertyValue(Inline.ForegroundProperty);
            if (temp != DependencyProperty.UnsetValue && temp is SolidColorBrush)
            {
                SolidColorBrush brush = (SolidColorBrush)temp;

                // Postavljanje trenutne boje teksta
                Color selectedColor = brush.Color;

                // Kreiranje liste svih boja
                List<string> colorNames = typeof(Colors).GetProperties().Select(p => p.Name).ToList();

                // Ako trenutna boja nije u listi, dodajemo je
                if (!colorNames.Contains(brush.Color.ToString()))
                {
                    colorNames.Insert(0, brush.Color.ToString());
                }

                // Postavljanje liste imena boja kao izvora podataka za ComboBoxColor
                ComboBoxColor.ItemsSource = colorNames;

                // Postavljanje trenutne boje teksta u ComboBoxColor
                ComboBoxColor.SelectedItem = brush.Color.ToString();
            }
        }

        private void InitializeColorComboBox()
        {
            // Get the list of color names
            List<string> colorNames = typeof(Colors).GetProperties().Select(p => p.Name).ToList();

            // Set the items source for ComboBoxColor
            ComboBoxColor.ItemsSource = colorNames;

            // Set the flag to true to indicate that the ComboBoxColor is initialized
            colorComboBoxInitialized = true;
        }

        private void AddPicture_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files (*.jpg, *.jpeg, *.png, *.gif)|*.jpg;*.jpeg;*.png;*.gif|All files (*.*)|*.*";
            if (openFileDialog.ShowDialog() == true)
            {
                // Kreiramo relativnu putanju za sliku unutar direktorijuma 'Images'
                string imageFileName = System.IO.Path.GetFileName(openFileDialog.FileName);
                string imagePath = System.IO.Path.Combine("Images", imageFileName);

                // Kreiramo punu putanju do ciljnog direktorijuma za čuvanje slike
                string destinationDirectory = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images");
                string destinationPath = System.IO.Path.Combine(destinationDirectory, imageFileName);

                // Ako direktorijum 'Images' ne postoji, kreiramo ga
                if (!System.IO.Directory.Exists(destinationDirectory))
                {
                    System.IO.Directory.CreateDirectory(destinationDirectory);
                }

                if (!System.IO.File.Exists(destinationPath))
                {
                    // Ako ne postoji, kopirajte je na ciljnu lokaciju
                    System.IO.File.Copy(openFileDialog.FileName, destinationPath);
                }
                else
                {
                    // Ako već postoji, možete prikazati poruku ili preduzeti neku drugu akciju
                    MessageBox.Show("Are you sure you want to select this picture");
                }

                // Postavljamo relativnu putanju slike
                footbalPlayers.ImagePath = imagePath;

                // Postavljamo sliku na labelu
                BitmapImage bitmap = new BitmapImage(new Uri(destinationPath));
                Image image = new Image();
                image.Source = bitmap;
                image.Stretch = Stretch.UniformToFill; // Postavi Stretch svojstvo na odgovarajuću vrednost

                imageLabel.Content = image;
            }

        }

        private void AddPlayer_Click(object sender, RoutedEventArgs e)
        {
            if (validate())
            {
                bp = footbalPlayers.ImagePath;
                string name = UserTextBox.Text + ".rtf";
                TextRange range;
                FileStream fStream;
                range = new TextRange(RichTextBox_AddWindiw.Document.ContentStart, RichTextBox_AddWindiw.Document.ContentEnd);
                fStream = new FileStream(name, FileMode.Create);
                range.Save(fStream, DataFormats.Rtf);
                fStream.Close();

                FootbalPlayers newPlayer = new FootbalPlayers();
                newPlayer.ShirtNumber = Int32.Parse(DressTextBox.Text);
                newPlayer.NameAndSurname = UserTextBox.Text;
                newPlayer.DateTime = DateTime.Now;
                newPlayer.RtfFilePath = name;
                newPlayer.ImagePath = bp;
                newPlayer.IsSelected = false;

                // Dodaj novog igrača u postojeću listu
                ShowWindow.FootballPlayers.Add(newPlayer);

                // Sačuvaj sve igrače u XML fajl
                serializer.SerializeObject(ShowWindow.FootballPlayers, "igraci.xml");

                // Osveži prikaz
                ShowWindow showWindow = Application.Current.Windows.OfType<ShowWindow>().FirstOrDefault();
                if (showWindow != null)
                {
                    showWindow.DataGridPlayers.Items.Refresh();
                }


                MessageBoxResult result = MessageBox.Show("Player successfully added!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                // Proveravamo da li korisnik kliknuo na OK dugme
                if (result == MessageBoxResult.OK)
                {
                    // Dodatna logika koja se izvršava nakon što korisnik klikne na OK
                    // Na primer, zatvaranje prozora ili neka druga akcija
                    Close();
                }
            }
        }

        private bool validate()
        {
            bool result = true;

            if (UserTextBox.Text.Trim().Equals("") || UserTextBox.Text.Trim().Equals("Input name and surname"))
            {
                result = false;
                UserTextBox.BorderBrush = Brushes.DarkRed;
                UsernameError.Text = "Name and surname are required!";
                UsernameError.Visibility = Visibility.Visible;
            }
            else
            {
                UserTextBox.Foreground = Brushes.Black;
                UserTextBox.BorderBrush = Brushes.Goldenrod;
                UsernameError.Text = "";
            }

            if (DressTextBox.Text.Trim().Equals("") || DressTextBox.Text.Equals("Input dress number"))
            {
                // Ako je polje prazno ili sadrži podrazumevanu poruku
                result = false;
                DressTextBox.BorderBrush = Brushes.DarkRed;
                DressError.Text = "Dress number is required!";
                DressError.Visibility = Visibility.Visible;
            }
            else
            {
                int dressNumber;
                if (!int.TryParse(DressTextBox.Text, out dressNumber))
                {
                    // Ako unos nije broj
                    result = false;
                    DressTextBox.BorderBrush = Brushes.DarkRed;
                    DressError.Text = "Dress must be a number!";
                    DressError.Visibility = Visibility.Visible;
                }
                else if (dressNumber < 0)
                {
                    // Ako je uneti broj manji ili jednak nuli
                    result = false;
                    DressTextBox.BorderBrush = Brushes.DarkRed;
                    DressError.Text = "Dress must be a positive number!";
                    DressError.Visibility = Visibility.Visible;
                }
                else
                {
                    // Ako je unos validan
                    DressTextBox.Foreground = Brushes.Black;
                    DressTextBox.BorderBrush = Brushes.Goldenrod;
                    DressError.Text = "";
                }
            }
            if (CountWord() <= 0)
            {
                RichTextBox_AddWindiw.BorderThickness = new Thickness(2); 
                RichTextBox_AddWindiw.BorderBrush = Brushes.DarkRed;
            }
            else
            {
                RichTextBox_AddWindiw.BorderThickness = new Thickness(1);
                RichTextBox_AddWindiw.BorderBrush = Brushes.Goldenrod;
            }

            // Provera da li je izabrana slika
            if (imageLabel.Content == null || imageLabel.Content.ToString() == "")
            {
                // Ako slika nije izabrana, postavite odgovarajući okvir i promenite rezultat u false
                imageLabel.BorderBrush = Brushes.DarkRed;
                imageLabel.BorderThickness = new Thickness(2);
                result = false;
            }
            else
            {
                // Ako je slika izabrana, resetujte okvir
                imageLabel.BorderBrush = Brushes.Goldenrod;
                imageLabel.BorderThickness = new Thickness(1);
            }

            return result;
        }

        private int CountWord()
        {
            int cw = 0, idx = 0;
            string richText = new TextRange(RichTextBox_AddWindiw.Document.ContentStart, RichTextBox_AddWindiw.Document.ContentEnd).Text;

            while (idx < richText.Length && char.IsWhiteSpace(richText[idx]))
                idx++;

            while (idx < richText.Length)
            {
                while (idx < richText.Length && !char.IsWhiteSpace(richText[idx]))
                    idx++;

                cw++;

                while (idx < richText.Length && char.IsWhiteSpace(richText[idx]))
                    idx++;
            }
            WordNumber.Text = cw.ToString();
            return cw;
        }

        private void Canvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();

        }

        private void ExitAddWindow_Click(object sender, RoutedEventArgs e)
        {           
            Close();
        }

        private void UserTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(UserTextBox.Text))
            {
                UserTextBox.Text = "Input name and surname";
                UserTextBox.Foreground = Brushes.LightGray;
            }
        }

        private void UserTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if(UserTextBox.Text.Trim().Equals("Input name and surname"))
            {
                UserTextBox.Text = "";
                UserTextBox.Foreground = Brushes.Black;
            }
        }

        private void DressTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(DressTextBox.Text))
            {
                DressTextBox.Text = "Input dress number";
                DressTextBox.Foreground = Brushes.LightGray;
            }
        }

        private void DressTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (DressTextBox.Text.Trim().Equals("Input dress number"))
            {
                DressTextBox.Text = "";
                DressTextBox.Foreground = Brushes.Black;
            }
        }

        private void RichTextBox_AddWindiw_TextChanged(object sender, TextChangedEventArgs e)
        {
            CountWord();
        }
    }
}
