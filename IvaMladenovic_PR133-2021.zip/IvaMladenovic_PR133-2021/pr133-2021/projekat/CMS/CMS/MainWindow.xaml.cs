﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CMS;
namespace CMS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static string AdminUsername = "admin";
        public static string AdminPassword = "admin123";
        public static string VisitorUsername = "visitor";
        public static string VisitorPassword = "visitor123";
        public MainWindow()
        {
            InitializeComponent();
            UsernameTextBox.Text = "Input user name";
            UsernameTextBox.Foreground = Brushes.LightSlateGray;
            PasswordTextBox.Password = "Input password";
            PasswordTextBox.Foreground = Brushes.LightSlateGray;
        }

        private void Canvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void Exit_Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult messageBoxResult = MessageBox.Show("Are you sure you want to exit?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (messageBoxResult == MessageBoxResult.Yes)
            {
                this.Close();
            }
            
        }
        private UserRoleEnum DetermineUserRole(string username, string password)
        {
            UserRole user = new UserRole { Username = username, Password = password };
            if (username == "admin" && password=="admin123")
            {
                user.Role = UserRoleEnum.Admin;
                return user.Role;
            }
            else if(username == "visitor" && password == "visitor123")
            {
                user.Role = UserRoleEnum.Visitor;
                return user.Role;
            }
            else
            {
                return UserRoleEnum.Invalid;
            }
            
        }

        private void Login_Button_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordTextBox.Password;


            if (string.IsNullOrEmpty(UsernameTextBox.Text.Trim()) || UsernameTextBox.Text == "Input user name")
            {
                UsernameTextBox.BorderBrush = Brushes.DarkRed;
                UsernameErrorTextBlock.Text = "Username is required!";
                UsernameErrorTextBlock.Visibility = Visibility.Visible;
            }
            else
            {
                UsernameTextBox.BorderBrush = Brushes.Black;
                UsernameErrorTextBlock.Visibility = Visibility.Collapsed;
            }

            // Provera lozinke
            if (string.IsNullOrEmpty(PasswordTextBox.Password.Trim()) || PasswordTextBox.Password == "Input password")
            {
                PasswordTextBox.BorderBrush = Brushes.DarkRed;
                PasswordErrorTextBlock.Text = "Password is required!";
                PasswordErrorTextBlock.Visibility = Visibility.Visible;
            }
            else
            {
                PasswordTextBox.BorderBrush = Brushes.Black;
                PasswordErrorTextBlock.Visibility = Visibility.Collapsed;
            }

          

            if (!string.IsNullOrEmpty(UsernameTextBox.Text.Trim()) && UsernameTextBox.Text != "Input user name" &&
            !string.IsNullOrEmpty(PasswordTextBox.Password.Trim()) && PasswordTextBox.Password != "Input password")
            {
                UserRole user = new UserRole { Username = username, Password = password };
                UserRoleEnum userRole = DetermineUserRole(username, password);
              
                using (StreamWriter writer = new StreamWriter("korisnici.txt", true))
                {

                    writer.WriteLine($"Username: {user.Username}, Password: {user.Password}, Role: {user.Role}");
                }


                if (userRole == UserRoleEnum.Admin)
                {
                    ShowWindow showWindow = new ShowWindow();
                    showWindow.Username = username;
                    showWindow.Password = password;
                    showWindow.Add_Button.Visibility = Visibility.Visible;
                    showWindow.Delete_Button.Visibility = Visibility.Visible;
                    showWindow.Show();
                    Close();

                } else if(userRole == UserRoleEnum.Visitor)
                {
                    ShowWindow showWindow = new ShowWindow();
                    showWindow.Username = username;
                    showWindow.Password = password;
                    showWindow.Add_Button.Visibility = Visibility.Hidden;
                    showWindow.Delete_Button.Visibility = Visibility.Hidden;
                    showWindow.Show();
                    Close();
                }


                if (username != "admin" && username != "visitor")
                {
                    UsernameTextBox.BorderBrush = Brushes.DarkRed;
                    UsernameErrorTextBlock.Text = "Wrong username!";
                    UsernameErrorTextBlock.Visibility = Visibility.Visible;

                    if (PasswordTextBox.Password != "admin123" && PasswordTextBox.Password != "visitor123")
                    {
                        PasswordTextBox.BorderBrush = Brushes.DarkRed;
                        PasswordErrorTextBlock.Text = "Wrong password!";
                        PasswordErrorTextBlock.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        PasswordTextBox.BorderBrush = Brushes.Black;
                        PasswordErrorTextBlock.Visibility = Visibility.Collapsed;
                    }
                }
                else
                {
                    UsernameTextBox.BorderBrush = Brushes.Black;
                    UsernameErrorTextBlock.Visibility = Visibility.Collapsed;

                    if ((username == "admin" && PasswordTextBox.Password != "admin123") ||
                        (username == "visitor" && PasswordTextBox.Password != "visitor123"))
                    {
                        PasswordTextBox.BorderBrush = Brushes.DarkRed;
                        PasswordErrorTextBlock.Text = "Wrong password!";
                        PasswordErrorTextBlock.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        PasswordTextBox.BorderBrush = Brushes.Black;
                        PasswordErrorTextBlock.Visibility = Visibility.Collapsed;
                    }
                }

            }
        }

        private void PasswordTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(PasswordTextBox.Password))
            {
                PasswordTextBox.Password = "Input password";
                PasswordTextBox.Foreground = Brushes.LightSlateGray;       
            }
        }

        private void PasswordTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (PasswordTextBox.Password.Trim().Equals("Input password"))
            {
                PasswordTextBox.Password = "";
                PasswordTextBox.Foreground = Brushes.Black;
            }
        }

        private void UsernameTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(UsernameTextBox.Text))
            {
                UsernameTextBox.Text = "Input user name";
                UsernameTextBox.Foreground = Brushes.LightSlateGray;
                
            }
        }

        private void UsernameTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (UsernameTextBox.Text.Trim().Equals("Input user name"))
            {
                UsernameTextBox.Text = "";
                UsernameTextBox.Foreground = Brushes.Black;
            }
        }
    }
}
